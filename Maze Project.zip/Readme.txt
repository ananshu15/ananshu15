This folder contains a header file called Project.h, a main file called the Project.cpp,
and five map txt file for five different maps of game. The projects contains three classes 
named graph, map and character class and the code is commented.
There is also 1 page report explaing what the project have. 